# ConnectArt 


## Alunos integrantes da equipe

Guilherme Lima Martini;
Inácio Mendonça Cintra;
Isaque Dias Noronha;
Luigi Castro Silveira;
Matheus Mota Cavalcante

## Professores responsáveis

Wladmir Cardoso Brandao;
Josiane

## Instruções de utilização

[Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.]
